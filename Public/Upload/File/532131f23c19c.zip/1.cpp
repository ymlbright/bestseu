#include<iostream>
#include<string>
using namespace std;

void main(){
	for(char i=65;i<91;i++)
		cout<<"\'"<<hex<<i<<"\', ";
}